# Issue #8 — Aura Elétrica Dinâmica
Especificação do plugin AURA, geração procedural de raios com ramificações e ancoragem nos landmarks do tronco e braços.
