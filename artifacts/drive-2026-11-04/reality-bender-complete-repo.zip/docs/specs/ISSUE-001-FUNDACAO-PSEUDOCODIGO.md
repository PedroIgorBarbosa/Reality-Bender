# Issue #1 — Fundação Executável
Especificação da estrutura base cliente/servidor, parseServerConfig, /api/health e handshake Socket.IO.
