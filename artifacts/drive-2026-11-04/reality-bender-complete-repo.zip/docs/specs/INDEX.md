# REALITY BENDER — Índice das especificações de implementação

**Propósito:** roteiro de consulta por issue para o Codex, sem ler todo o projeto indiscriminadamente. Os documentos descrevem **como implementar**, mas não comprovam que a funcionalidade foi executada.

**Hierarquia de contratos:**
1. `AGENTS.md` rege o fluxo dos agentes e a memória obrigatória em `documentos de contexto/`.
2. `docs/REALITY_BENDER_ERS_v1.0.md` é o contrato de produto e requisitos.
3. Cada especificação `docs/specs/ISSUE-XXX-...` detalha algoritmos, contratos, testes e exceções da issue correspondente.
4. O código e testes efetivamente executados são a evidência de implementação; registros do grafo são memória auxiliar, não prova de funcionamento.

## Diretório de especificações

| Issue | Documento | Conteúdo | Depende de |
| --- | --- | --- | --- |
| [#1](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/1) | [ISSUE-001-FUNDACAO-PSEUDOCODIGO.md](ISSUE-001-FUNDACAO-PSEUDOCODIGO.md) | Fundação executável (React, Node, Socket.IO, contratos, CI) | — |
| [#2](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/2) | [ISSUE-002-SESSOES-PAREAMENTO-PSEUDOCODIGO.md](ISSUE-002-SESSOES-PAREAMENTO-PSEUDOCODIGO.md) | Sessões, QR Code, convites e papéis de autorização | #1 |
| [#3](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/3) | [ISSUE-003-CAMERA-WEBRTC-PSEUDOCODIGO.md](ISSUE-003-CAMERA-WEBRTC-PSEUDOCODIGO.md) | Câmera via WebRTC e renderização em /stage | #2 |
| [#4](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/4) | [ISSUE-004-PROJECAO-GEOMETRIA-PSEUDOCODIGO.md](ISSUE-004-PROJECAO-GEOMETRIA-PSEUDOCODIGO.md) | Projeção 3D e calibração geométrica | #3 |
| [#5](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/5) | [ISSUE-005-MEDIAPIPE-GESTOS-PSEUDOCODIGO.md](ISSUE-005-MEDIAPIPE-GESTOS-PSEUDOCODIGO.md) | Detecção de gestos (MediaPipe) | #4 |
| [#6](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/6) | [ISSUE-006-ESFERA-ENERGIA-PSEUDOCODIGO.md](ISSUE-006-ESFERA-ENERGIA-PSEUDOCODIGO.md) | Efeito interativo Esfera de Energia | #5 |
| [#7](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/7) | [ISSUE-007-PORTAL-DIMENSIONAL-PSEUDOCODIGO.md](ISSUE-007-PORTAL-DIMENSIONAL-PSEUDOCODIGO.md) | Efeito interativo Portal Dimensional | #5 |
| [#8](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/8) | [ISSUE-008-AURA-ELETRICA-PSEUDOCODIGO.md](ISSUE-008-AURA-ELETRICA-PSEUDOCODIGO.md) | Efeito interativo Aura Elétrica | #5 |
| [#9](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/9) | [ISSUE-009-OPERACAO-RESILIENCIA-PSEUDOCODIGO.md](ISSUE-009-OPERACAO-RESILIENCIA-PSEUDOCODIGO.md) | Resiliência, reconexão e fallback em campo | #6, #7, #8 |
| [#10](https://github.com/PedroIgorBarbosa/Reality-Bender/issues/10) | [ISSUE-010-HOMOLOGACAO-PSEUDOCODIGO.md](ISSUE-010-HOMOLOGACAO-PSEUDOCODIGO.md) | CT-010-1 a CT-010-7 e homologação final | #9 |
