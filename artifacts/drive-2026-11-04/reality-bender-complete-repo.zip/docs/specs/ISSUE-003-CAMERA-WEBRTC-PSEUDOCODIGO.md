# Issue #3 — Câmera Real e Transmissão WebRTC
Especificação de captura getUserMedia, troca de câmera, negociação SDP/ICE com fila de candidatos e reconexão.
