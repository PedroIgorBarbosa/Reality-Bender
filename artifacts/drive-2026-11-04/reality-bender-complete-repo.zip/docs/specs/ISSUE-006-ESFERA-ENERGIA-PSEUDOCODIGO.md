# Issue #6 — Esfera de Energia Cinematográfica
Especificação do plugin ENERGY, estado da esfera, carga progressiva, raio entre duas mãos e renderização WebGL/Three.js.
