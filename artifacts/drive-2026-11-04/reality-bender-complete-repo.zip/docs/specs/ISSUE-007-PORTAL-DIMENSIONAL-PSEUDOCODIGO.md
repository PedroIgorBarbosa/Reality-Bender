# Issue #7 — Portal Dimensional 3D
Especificação do plugin PORTAL, detecção de gesto circular, orientação 3D da palma, vórtice energético e fechamento gradual.
