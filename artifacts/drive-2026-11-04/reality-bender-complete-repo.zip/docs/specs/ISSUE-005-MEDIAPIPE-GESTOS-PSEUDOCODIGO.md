# Issue #5 — MediaPipe, Calibração e Motor de Gestos
Especificação de detecção de mãos/pose, OneEuroFilter, classificação de gestos, abertura/orientação de palma e máquina de calibração.
