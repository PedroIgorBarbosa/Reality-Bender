# Issue #4 — Projeção e Geometria do Vídeo
Especificação de computeContentRect, videoNormalizedToStage, stageCssToNormalized, RenderQuality e atalhos de palco.
