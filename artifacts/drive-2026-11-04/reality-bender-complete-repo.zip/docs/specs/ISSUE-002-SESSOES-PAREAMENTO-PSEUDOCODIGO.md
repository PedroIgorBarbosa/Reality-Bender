# Issue #2 — Sessões Efêmeras e Pareamento QR/PIN
Especificação de gerenciamento de sessões, PIN de 6 dígitos, token de 128+ bits, expiração TTL de 5 minutos e isolamento de sala.
