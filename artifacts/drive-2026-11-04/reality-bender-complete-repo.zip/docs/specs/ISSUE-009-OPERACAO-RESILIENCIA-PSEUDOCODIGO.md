# Issue #9 — Operação, Resiliência e Diagnósticos
Especificação de comandos remotos com ACK, detector de congelamento de vídeo (<3s), reconexão WebRTC e métricas FPS/P50/P95.
