# Especificação de Requisitos do Sistema (ERS) — REALITY BENDER v1.0

## 1. Visão Geral
O **Reality Bender** é um sistema interativo em tempo real para apresentações ao vivo em que um smartphone atua como câmera sem fio e controle remoto (`/control`) e um computador conectado a um projetor/data-show (`/stage`) exibe o vídeo ao vivo com rastreamento corporal/mãos (MediaPipe) e efeitos visuais 3D (Three.js / WebGL2: Esfera de Energia, Portal Dimensional e Aura Elétrica).

## 2. Requisitos Funcionais (RF-01 a RF-26)
- **RF-01**: Disponibilizar rotas `/stage` (PC/Projetor) e `/control` (Celular) servidas pela mesma aplicação.
- **RF-02**: Criar sessões efêmeras no `/stage` com token criptográfico (>= 128 bits) e PIN de 6 dígitos com expiração (TTL 5 min).
- **RF-03**: Exibir QR Code e link/código de pareamento na `/stage` para conexão rápida do celular.
- **RF-04**: Solicitar permissão de câmera no `/control` mediante gesto explícito do usuário (`getUserMedia`, `audio: false`).
- **RF-05**: Permitir alternar entre câmera traseira (`environment`) e frontal (`user`) no `/control`.
- **RF-06**: Garantir que apenas um emissor móvel controle a sessão ativa, recusando conexões intrusas sem derrubar a sessão em andamento.
- **RF-07**: Validar contexto seguro (HTTPS/localhost) antes de acessar `navigator.mediaDevices.getUserMedia`.
- **RF-08**: Transmitir o fluxo de vídeo ao vivo via WebRTC P2P (`RTCPeerConnection`) entre `/control` e `/stage`.
- **RF-09**: Reconstituir automaticamente a sessão e a negociação WebRTC em caso de queda temporária de rede.
- **RF-10**: Renderizar o vídeo remoto em tempo real na `/stage` sem utilizar vídeos gravados ou imagens estáticas.
- **RF-11**: Transformar coordenadas normalizadas (0..1) do vídeo para o espaço do palco (CSS/NDC) respeitando proporção (`contain`/`cover`), orientação retrato/paisagem e espelhamento (`videoNormalizedToStage`).
- **RF-12**: Executar rastreamento de até 2 mãos (21 landmarks por mão) via MediaPipe Hands sobre os quadros de vídeo na `/stage`.
- **RF-13**: Executar rastreamento de pose corporal (tronco, ombros, cotovelos e punhos) via MediaPipe Pose na `/stage`.
- **RF-14**: Suavizar coordenadas e gestos temporalmente (`OneEuroFilter` / `EMAFilter`) para eliminar tremulação sem introduzir atraso perceptível.
- **RF-15**: Classificar gestos determinísticos (`OPEN_PALM`, `CLOSED_FIST`, `PINCH`, `INDEX_POINTING`, `PEACE`, `UNKNOWN`) e calcular distância de pinch, centroide, abertura e orientação da palma.
- **RF-16**: Gerenciar máquina de estados de calibração (`UNINITIALIZED`, `CALIBRATING`, `CALIBRATED`, `LOST`).
- **RF-17**: Implementar arquitetura de plugins de efeitos (`EffectPlugin`) com ciclo único de `requestAnimationFrame` e liberação determinística de recursos de GPU.
- **RF-18**: Renderizar o efeito **Esfera de Energia** (`ENERGY`) entre as mãos com raio proporcional à distância entre palmas, acúmulo de carga e partículas/arcos.
- **RF-19**: Renderizar o efeito **Portal Dimensional** (`PORTAL`) ancorado à palma aberta ou gesto circular, respondendo à orientação 3D e abertura da mão.
- **RF-20**: Renderizar o efeito **Aura Elétrica** (`AURA`) com raios procedurais ancorados ao tronco e braços, modulados pela velocidade de movimento.
- **RF-21**: Permitir troca de efeitos (`NONE`, `ENERGY`, `PORTAL`, `AURA`) tanto por atalhos de teclado na `/stage` (`0`–`3`) quanto remotamente pelo `/control` com confirmação ACK.
- **RF-22**: Suportar perfis de qualidade de renderização (`HIGH`, `MEDIUM`, `COMPAT`) e espelhamento horizontal.
- **RF-23**: Disponibilizar modo tela cheia (tecla `F` ou botão) na `/stage`.
- **RF-24**: Exibir diagnóstico operacional em tempo real (`DiagnosticsHud`) com FPS de renderização, FPS de vídeo, latência de inferência P50/P95, RTT de sinalização e estado WebRTC.
- **RF-25**: Detectar congelamento de quadros de vídeo em até 3 segundos (`verificarDisponibilidadeDeVideo`) e sinalizar estado `INTERRUPTED`.
- **RF-26**: Encerrar sessões limpando todos os listeners, timers, `MediaStreamTrack`, `RTCPeerConnection` e buffers WebGL.

## 3. Requisitos Não Funcionais (RNF-01 a RNF-20)
- **RNF-01 a RNF-05**: Desempenho de rastreamento e renderização sem fila crescente de inferência (backpressure de 1 quadro em voo).
- **RNF-06 a RNF-10**: Segurança de origem (CORS restrito), headers HTTP seguros, tokens de 128+ bits e isolamento por sala.
- **RNF-11 a RNF-20**: Código em TypeScript estrito, testes automatizados verificáveis, rastreabilidade em grafo de conhecimento JSON e documentação operacional completa.

## 4. Casos de Teste de Homologação (CT-01 a CT-18 / CT-010-1 a CT-010-7)
- **CT-01 (CT-010-1)**: Isolamento de sessão, validação de PIN/token e proteção contra intrusão.
- **CT-02 (CT-010-2)**: Sinalização e negociação WebRTC P2P com fila de candidatos ICE e reconexão.
- **CT-03 (CT-010-3)**: Geometria de projeção (`videoNormalizedToStage`) em retrato, paisagem e espelhamento.
- **CT-04 (CT-010-4)**: Controle de backpressure na fila de inferência MediaPipe e suavização temporal.
- **CT-05 (CT-010-5)**: Reatividade determinística dos efeitos `ENERGY`, `PORTAL` e `AURA` aos landmarks e gestos.
- **CT-06 (CT-010-6)**: Detecção de congelamento de vídeo (< 3s) e recuperação de falhas sem travar a UI.
- **CT-07 (CT-010-7)**: Limpeza integral de recursos (tracks, peers, sockets, GPU) ao encerrar sessão.
